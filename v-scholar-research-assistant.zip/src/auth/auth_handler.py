import streamlit as st
import streamlit_authenticator as stauth
import sqlite3
import os
from loguru import logger
from typing import Optional, Dict, Any

class AuthHandler:
    """
    Handles user authentication using streamlit-authenticator and SQLite.
    """
    
    def __init__(self, db_path: str = "vscholar_users.db"):
        self.db_path = db_path
        self._init_db()
        self.authenticator: Optional[stauth.Authenticate] = None

    def _init_db(self):
        """Initializes the SQLite database if it doesn't exist."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                password TEXT NOT NULL,
                email TEXT NOT NULL
            )
        ''')
        
        # Check if we have any users, if not add a default admin for testing (password: admin123)
        # Note: In production, this should be handled via a registration form
        cursor.execute("SELECT COUNT(*) FROM users")
        if cursor.fetchone()[0] == 0:
            logger.info("No users found in database. Creating default admin user.")
            from bcrypt import hashpw, gensalt
            hashed_pw = hashpw("admin123".encode('utf-8'), gensalt()).decode('utf-8')
            cursor.execute(
                "INSERT INTO users (username, name, password, email) VALUES (?, ?, ?, ?)",
                ("admin", "Administrator", hashed_pw, "admin@vscholar.edu.vn")
            )
        
        conn.commit()
        conn.close()

    def _get_credentials_from_db(self) -> Dict[str, Any]:
        """Fetches all users from SQLite and formats them for streamlit-authenticator."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users")
        rows = cursor.fetchall()
        
        credentials = {"usernames": {}}
        for row in rows:
            credentials["usernames"][row["username"]] = {
                "name": row["name"],
                "password": row["password"],
                "email": row["email"]
            }
        
        conn.close()
        return credentials

    def login(self):
        """
        Renders the login UI and handles the authentication logic.
        Returns the name, authentication_status, and username.
        """
        credentials = self._get_credentials_from_db()
        
        # Initialize authenticator
        # cookie_name, key, and cookie_expiry should ideally be in .env
        cookie_name = os.getenv("AUTH_COOKIE_NAME", "vscholar_auth_cookie")
        key = os.getenv("AUTH_COOKIE_KEY", "vscholar_signature_key")
        cookie_expiry = int(os.getenv("AUTH_COOKIE_EXPIRY", "30"))
        
        self.authenticator = stauth.Authenticate(
            credentials,
            cookie_name,
            key,
            cookie_expiry,
            auto_hash=False # We handle hashing ourselves or expect hashed in DB
        )
        
        # Render login widget
        name, authentication_status, username = self.authenticator.login('Login', 'main')
        
        if authentication_status:
            logger.info(f"User {username} logged in successfully.")
            st.session_state["username"] = username
            st.session_state["name"] = name
        elif authentication_status == False:
            st.error('Username/password is incorrect')
            logger.warning(f"Failed login attempt for username: {username}")
        elif authentication_status == None:
            st.warning('Please enter your username and password')
            
        return name, authentication_status, username

    def logout(self):
        """Handles user logout."""
        if self.authenticator:
            self.authenticator.logout('Logout', 'sidebar')
            logger.info("User logged out.")

    def register_user(self, username, name, password, email):
        """Allows programmatically adding a new user to the DB."""
        from bcrypt import hashpw, gensalt
        hashed_pw = hashpw(password.encode('utf-8'), gensalt()).decode('utf-8')
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO users (username, name, password, email) VALUES (?, ?, ?, ?)",
                (username, name, hashed_pw, email)
            )
            conn.commit()
            conn.close()
            logger.info(f"User {username} registered successfully.")
            return True
        except sqlite3.IntegrityError:
            logger.error(f"Failed to register {username}: Username already exists.")
            return False
        except Exception as e:
            logger.error(f"Error registering user: {str(e)}")
            return False

# Global instance
auth_handler = AuthHandler()
