import streamlit as st
from loguru import logger
from auth.auth_handler import auth_handler
from api.key_manager import key_manager
from nlp.vietnamese_processor import process_and_translate

# Page configuration
st.set_page_config(
    page_title="V-Scholar Research Assistant",
    page_icon="🎓",
    layout="wide",
)

def main():
    """Main application loop."""
    
    # 1. Authentication
    name, authentication_status, username = auth_handler.login()
    
    if authentication_status:
        # Success: Show the app content
        auth_handler.logout()
        st.write(f"## Chào mừng {name} đến với V-Scholar! 👋")
        
        # Sidebar for status and keys
        with st.sidebar:
            st.divider()
            st.write("### Trạng thái hệ thống")
            status = key_manager.get_status()
            st.info(f"Gemini Keys: {status['gemini']['count']}")
            st.info(f"Groq Keys: {status['groq']['count']}")
            
        # Main UI Tabs
        tab1, tab2, tab3 = st.tabs(["🔍 Tìm kiếm đề tài", "📚 Tổng quan tài liệu", "📝 Khung đề cương"])
        
        with tab1:
            st.header("Khám phá đề tài nghiên cứu")
            
            col1, col2 = st.columns(2)
            with col1:
                research_level = st.selectbox(
                    "Cấp độ nghiên cứu",
                    ["Khóa luận tốt nghiệp (Đại học)", "Luận văn (Thạc sĩ)", "Luận án (Tiến sĩ)", "Đề tài/Dự án"]
                )
                
                institution = st.text_input("Đơn vị công tác/Học tập (Trường, Khoa, Viện)")
                
            with col2:
                field = st.text_input("Lĩnh vực quan tâm (Ví dụ: Trí tuệ nhân tạo, Ngôn ngữ học...)")
                keywords_input = st.text_area("Từ khóa hoặc ý tưởng ban đầu (Tiếng Việt)")

            if st.button("Xử lý và Tìm kiếm"):
                if keywords_input:
                    with st.spinner("Đang phân tích và xử lý ngôn ngữ..."):
                        try:
                            nlp_result = process_and_translate(keywords_input)
                            
                            st.success("Xử lý thành công!")
                            
                            c1, c2 = st.columns(2)
                            with c1:
                                st.write("**Từ khóa tiếng Việt:**")
                                st.write(f"{', '.join(nlp_result['keywords'])}")
                            with c2:
                                st.write("**Dịch tiếng Anh:**")
                                st.write(f"_{nlp_result['english_translation']}_")
                            
                            # Next steps would be searching via DuckDuckGo and Crossref
                            st.info("Module tìm kiếm Search (DuckDuckGo/Crossref) sẽ được thực hiện ở các bước tiếp theo.")
                            
                        except Exception as e:
                            st.error(f"Lỗi xử lý: {str(e)}")
                            logger.error(f"NLP Processing Error: {str(e)}")
                else:
                    st.warning("Vui lòng nhập từ khóa để bắt đầu.")

    elif authentication_status == False:
        # Error: Handled by auth_handler.login()
        pass
    elif authentication_status == None:
        # Initial state: Show some welcome info
        st.info("Vui lòng đăng nhập để sử dụng V-Scholar.")

if __name__ == "__main__":
    main()
